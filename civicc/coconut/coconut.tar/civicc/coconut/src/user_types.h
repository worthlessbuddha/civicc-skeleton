#pragma once

#include "palm/hash_table.h"

typedef htable_st *htable_ptr;
